// ===== MENU RESPONSIVO =====
const menuToggle = document.getElementById("menu-toggle");
const navLinks = document.getElementById("nav-links");

function fecharMenu() {
  navLinks.classList.remove("open");
  menuToggle.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
}

menuToggle.addEventListener("click", () => {
  const aberto = navLinks.classList.toggle("open");
  menuToggle.classList.toggle("open", aberto);
  menuToggle.setAttribute("aria-expanded", String(aberto));
});

// Fecha o menu ao clicar em um link (no celular)
navLinks.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", fecharMenu);
});

// ===== LINK ATIVO CONFORME A SEÇÃO VISÍVEL =====
const secoes = document.querySelectorAll("main section[id]");
const linksMenu = document.querySelectorAll(".nav-links a");

const observadorSecoes = new IntersectionObserver(
  (entradas) => {
    entradas.forEach((entrada) => {
      if (entrada.isIntersecting) {
        linksMenu.forEach((link) => {
          link.classList.toggle(
            "active",
            link.getAttribute("href") === "#" + entrada.target.id
          );
        });
      }
    });
  },
  { rootMargin: "-40% 0px -55% 0px" }
);

secoes.forEach((secao) => observadorSecoes.observe(secao));

// ===== ANIMAÇÃO DAS BARRAS DE HABILIDADES =====
const barras = document.querySelectorAll(".skill-progress");

const observadorBarras = new IntersectionObserver(
  (entradas, observador) => {
    entradas.forEach((entrada) => {
      if (entrada.isIntersecting) {
        entrada.target.style.width = entrada.target.dataset.level + "%";
        observador.unobserve(entrada.target);
      }
    });
  },
  { threshold: 0.4 }
);

barras.forEach((barra) => observadorBarras.observe(barra));

// ===== FORMULÁRIO DE CONTATO (validação simples) =====
const form = document.getElementById("contact-form");
const status = document.getElementById("form-status");

form.addEventListener("submit", (evento) => {
  evento.preventDefault();

  const nome = form.nome.value.trim();
  const email = form.email.value.trim();
  const mensagem = form.mensagem.value.trim();
  const emailValido = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

  status.className = "form-status";

  if (!nome || !email || !mensagem) {
    status.textContent = "Preencha todos os campos.";
    status.classList.add("erro");
    return;
  }

  if (!emailValido) {
    status.textContent = "Digite um e-mail válido.";
    status.classList.add("erro");
    return;
  }

  // Aqui o formulário apenas simula o envio.
  // Para enviar de verdade, use um serviço como Formspree ou EmailJS.
  status.textContent = "Mensagem enviada com sucesso! (simulação)";
  status.classList.add("sucesso");
  form.reset();
});

// ===== ANO AUTOMÁTICO NO RODAPÉ =====
document.getElementById("ano").textContent = new Date().getFullYear();
